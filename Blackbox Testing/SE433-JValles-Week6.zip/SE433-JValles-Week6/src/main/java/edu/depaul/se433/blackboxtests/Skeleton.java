package edu.depaul.se433.blackboxtests;

public class Skeleton {

}
