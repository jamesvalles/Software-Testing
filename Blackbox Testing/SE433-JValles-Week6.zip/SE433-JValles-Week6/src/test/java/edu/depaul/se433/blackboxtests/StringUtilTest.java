/**
 * This class is used to run parameterized tests on noun pluralization problem.
 */

package edu.depaul.se433.blackboxtests;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertThrows;
import edu.depaul.se433.StringUtil;
import java.util.stream.Stream;
import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.params.ParameterizedTest;
import org.junit.jupiter.params.provider.Arguments;
import org.junit.jupiter.params.provider.MethodSource;

public class StringUtilTest {

  /**
   * This test checks that nouns are pluralized correctly.
   */

  @ParameterizedTest
  @DisplayName("The word is in the correct plural form. ")
  @MethodSource("pluralizationTest")
  void checkPluralization(String word, String expected) {
    String actual =  StringUtil.pluralize(word);
    assertEquals(expected, actual);
  }


  private static Stream<Arguments> pluralizationTest() {
    return Stream.of(
        Arguments.of("Cat", "Cats"),
        Arguments.of("Bus", "Buses"),
        Arguments.of("Wife", "Wives"),
        Arguments.of("Roof", "Roofs"),
        Arguments.of("Puppy", "Puppies"),
        Arguments.of("Boy", "Boys"),
        Arguments.of("Potato", "Potatoes"),
        Arguments.of("Cactus", "Cacti"),
        Arguments.of("Analysis", "Analyses"),
        Arguments.of("Phenomenon", "Phenomena"),
        Arguments.of("Sheep", "Sheep"),
        Arguments.of("Cats", "Cats"),
        Arguments.of("Gas", "Gasses")
    );
  }

  /**
   * This test checks special cases, specifically invalid word input.
   */

  @ParameterizedTest
  @DisplayName("Exception thrown for an invalid word.")
  @MethodSource("invalidWordExceptionTest")
  void invalidValueCheck(Class expected, String word) {
    assertThrows(expected, () -> StringUtil.pluralize(word));
  }

  private static Stream<Arguments> invalidWordExceptionTest() {
    return Stream.of(
        Arguments.of(Exception.class, "Gato"),
        Arguments.of(Exception.class, "12345667")
    );
  }


  /**
   * This test checks that Irregular Nouns are pluralized correctly.
   */

  @ParameterizedTest
  @DisplayName("Irregular noun is in the correct plural form.")
  @MethodSource("irregularNounPluralization")
  void irregularNounPluralization(String word, String expected) {
    String actual =  StringUtil.pluralize(word);
    assertEquals(expected, actual);
  }


  private static Stream<Arguments> irregularNounPluralization() {
    return Stream.of(
        Arguments.of("Tooth", "Teeth"),
        Arguments.of("Woman", "Women"),
        Arguments.of("Person", "People"),
        Arguments.of("Bacterium", "Bacteria"),
        Arguments.of("Datum", "Data")
    );
  }
}

