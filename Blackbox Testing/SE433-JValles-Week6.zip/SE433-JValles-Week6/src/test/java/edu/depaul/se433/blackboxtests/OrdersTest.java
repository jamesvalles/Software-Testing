/**
 * This class is used to run parameterized tests on order calculation problem.
 */

package edu.depaul.se433.blackboxtests;


import static org.junit.jupiter.api.Assertions.*;
import edu.depaul.se433.Orders;
import edu.depaul.se433.Orders.ShippingMethod;
import java.util.stream.Stream;
import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.params.ParameterizedTest;
import org.junit.jupiter.params.provider.Arguments;
import org.junit.jupiter.params.provider.MethodSource;

public class OrdersTest {


  /**
   * This test checks that total calculation is correct for different shipping type, amount or state.
   * */

  @ParameterizedTest
  @DisplayName("Correct total calculations based on either different shipping type, amount, or state.")
  //6% tax must exclude shipping cost.
  @MethodSource("ordersTest")
  void calculateCorrectTotal(Double expected, Double rawTotal, Orders.ShippingMethod shippingMethod,
      String destination) {
    Orders orders = new Orders();
    //Using floor to truncate values two decimal places could have also used 1E-2
    double total =
        Math.floor(orders.calculateTotal(rawTotal, shippingMethod, destination) * 100) / 100;
    assertEquals(expected, total);
  }


  private static Stream<Arguments> ordersTest() {
    return Stream.of(
        Arguments.of(54.06, 51.00, ShippingMethod.Standard, "IL"),
        Arguments.of(51.00, 51.00, ShippingMethod.Standard, "FL"),
        Arguments.of(79.06, 51.00, ShippingMethod.NextDay, "CA"),
        Arguments.of(76.00, 51.00, ShippingMethod.NextDay, "GA"),
        Arguments.of(74.00, 49.00, ShippingMethod.NextDay, "TX"),
        Arguments.of(61.94, 49.00, ShippingMethod.Standard, "IL"),
        Arguments.of(59.00, 49.00, ShippingMethod.Standard, "WI"),
        Arguments.of(76.94, 49.00, ShippingMethod.NextDay, "IL"),
        Arguments.of(74.00, 49.00, ShippingMethod.NextDay, "CO"),

        //Boundary & Special Value Analysis
        Arguments.of(62.98, 49.99, ShippingMethod.Standard, "IL"),
        Arguments.of(60.00, 50.00, ShippingMethod.Standard, "TX"),
        Arguments.of(53.01, 50.01, ShippingMethod.Standard, "NY"),
        Arguments.of(50.02, 50.02, ShippingMethod.Standard, "CO"),
        Arguments.of(10.02, 0.02, ShippingMethod.Standard, "IL"),
        Arguments.of(10.01, 0.01, ShippingMethod.Standard, "IL"),
        Arguments.of(75.00, 50.00, ShippingMethod.NextDay, "TX"),
        Arguments.of(78.01, 50.01, ShippingMethod.NextDay, "NY"),
        Arguments.of(75.02, 50.02, ShippingMethod.NextDay, "CO"),
        Arguments.of(25.02, 0.02, ShippingMethod.NextDay, "IL"),
        Arguments.of(25.01, 0.01, ShippingMethod.NextDay, "IL")
    );
  }

  /**
   * This test checks that an error is thrown when an invalid value for either customer's state or purchase amount.
   */


  @ParameterizedTest
  @DisplayName("Throws Exception for invalid values for either Customer State or [Purchase Amount.")
  @MethodSource("invalidValueTest")
  void invalidValueCheck(Class expected, Double rawTotal, Orders.ShippingMethod shippingMethod,
      String destination) {
    Orders orders = new Orders();
    assertThrows(expected, () -> orders.calculateTotal(rawTotal, shippingMethod, destination));
  }

  private static Stream<Arguments> invalidValueTest() {
    return Stream.of(
        Arguments.of(Exception.class, 51.00, ShippingMethod.Standard, "PR"),
        Arguments.of(Exception.class, 51.00, ShippingMethod.Standard, "PR"),
        Arguments.of(Exception.class, 49.00, ShippingMethod.Standard, "PR"),
        Arguments.of(Exception.class, 51.00, ShippingMethod.NextDay, "PR"),
        Arguments.of(Exception.class, 49.00, ShippingMethod.NextDay, "PR"),

        //Arguments.of(Exception.class, 0.00, ShippingMethod.Invalid, "IL") wanted to test invalid shipping option, but enum will not allow.

        //Invalid Purchase Amount
        Arguments.of(Exception.class, 0.00, ShippingMethod.NextDay, "CO"),
        Arguments.of(Exception.class, 0.00, ShippingMethod.Standard, "IL"),
        Arguments.of(Exception.class, 0.00, ShippingMethod.Standard, "TX"),
        Arguments.of(Exception.class, 0.00, ShippingMethod.NextDay, "IL"),
        Arguments.of(Exception.class, 0.00, ShippingMethod.NextDay, "TX")
    );
  }
}
