/**
 * This class is used to run parameterized tests on noun pluralization problem.
 */

package edu.depaul.se433.blackboxtests;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertThrows;
import static org.junit.jupiter.api.Assertions.fail;

import java.util.stream.Stream;
import org.junit.Test;
import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.params.ParameterizedTest;
import org.junit.jupiter.params.provider.Arguments;
import org.junit.jupiter.params.provider.MethodSource;

public class StringUtilTest {

  /**
   * This test checks that nouns are pluralized correctly.
   */

  @ParameterizedTest
  @DisplayName("The word is in the correct plural form. ")
  @MethodSource("pluralizationTest")
  void checkPluralization(String word, String expected) {
    String actual =  StringUtil.pluralize(word);
    assertEquals(expected, actual);
  }


  private static Stream<Arguments> pluralizationTest() {
    return Stream.of(
        Arguments.of("Cat", "Cats"),
        Arguments.of("Bus", "Buses"),
        Arguments.of("Wife", "Wives"),
        Arguments.of("Roof", "Roofs"),
        Arguments.of("Puppy", "Puppies"),
        Arguments.of("Boy", "Boys"),
        Arguments.of("Potato", "Potatoes"),
        Arguments.of("Cactus", "Cacti"),
        Arguments.of("Analysis", "Analyses"),
        Arguments.of("Phenomenon", "Phenomena"),
        Arguments.of("Sheep", "Sheep"),
        Arguments.of("Cats", "Cats"),
        Arguments.of("Gas", "Gasses"),


        //Adding new tests to improve code coverage via Jacoco
        Arguments.of("equipment", "equipment"),
        Arguments.of("person", "person"),
        Arguments.of(null, null),
        Arguments.of(",", ","),
        Arguments.of("array", "arrays"),
        Arguments.of("chimney", "chimneys"),
        Arguments.of("guy", "chimneys")

    );
  }

  /**Added this test to increase converage of Main() in StringUtil and StringUUtil constructor
   * This test checks that main doesn't throw an illegalArgumentException */

  @ParameterizedTest
  @DisplayName("Exception thrown main method.")
  @MethodSource("invalidMainExceptionTest")
  void mainMethodCheck(Class expected, String[] args) {

    StringUtil stringUtil = new StringUtil();
    try{
     stringUtil.main(args);}
    catch (Exception e){
      fail("Should not throw an exception");
    }
  }

  private static Stream<Arguments> invalidMainExceptionTest() {
    return Stream.of(
        Arguments.of(Test.None.class, null)
    );
  }

  /**
   * This test checks special cases, specifically invalid word input.
   */

  @ParameterizedTest
  @DisplayName("Exception thrown for an invalid word.")
  @MethodSource("invalidWordExceptionTest")
  void invalidValueCheck(Class expected, String word) {
    assertThrows(expected, () -> StringUtil.pluralize(word));
  }

  private static Stream<Arguments> invalidWordExceptionTest() {
    return Stream.of(
        Arguments.of(Exception.class, "Gato"),
        Arguments.of(Exception.class, "12345667")
    );
  }





  /**
   * This test checks that Irregular Nouns are pluralized correctly.
   */

  @ParameterizedTest
  @DisplayName("Irregular noun is in the correct plural form.")
  @MethodSource("irregularNounPluralization")
  void irregularNounPluralization(String word, String expected) {
    String actual =  StringUtil.pluralize(word);
    assertEquals(expected, actual);
  }


  private static Stream<Arguments> irregularNounPluralization() {
    return Stream.of(
        Arguments.of("Tooth", "Teeth"),
        Arguments.of("Woman", "Women"),
        Arguments.of("Person", "People"),
        Arguments.of("Bacterium", "Bacteria"),
        Arguments.of("Datum", "Data")
    );
  }
}

